# AGENTS.md

This document provides an overview of the project structure for developers and AI agents working on this codebase.

## Project Overview

A personal hybrid training dashboard for armwrestling performance and general strength/aesthetics. Single-page app with four tabs: Schedule, Progress, Table, Profile. All state persists to `localStorage` — no backend required.

## Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 + inline styles |
| Charts | Chart.js v4 + react-chartjs-2 |
| Fonts | Syne (display) via Google Fonts, JetBrains Mono (data/numbers) |
| Persistence | localStorage only |
| Deployment | Netlify |

## Directory Structure

```
├── public/
│   └── favicon.ico
├── src/
│   ├── components/          # Currently unused — all UI is in routes
│   ├── routes/
│   │   ├── __root.tsx       # Root layout: dark body, HeadContent, Scripts
│   │   └── index.tsx        # Full dashboard (Schedule / Progress / Table / Profile)
│   ├── router.tsx           # TanStack Router setup with routeTree
│   └── styles.css           # Tailwind import, Google Fonts, dark theme CSS vars, scrollbar
├── netlify.toml             # Build: vite build, publish: dist/client
├── package.json
├── tsconfig.json            # Strict mode, @/* alias for src/*
└── vite.config.ts           # TanStack Start + Netlify + Tailwind plugins
```

## Key Architecture Decisions

### Single-file dashboard
All dashboard logic lives in `src/routes/index.tsx`. This was intentional for this project size — it avoids prop-drilling complexity and keeps the schedule data, state, and UI co-located. If it grows significantly, split into `src/components/ScheduleTab.tsx`, `ProgressTab.tsx`, etc.

### localStorage schema
All persistence uses `localStorage`. Keys:

| Key | Type | Content |
|-----|------|---------|
| `aw_profile` | `Profile` | Athlete profile fields |
| `aw_completion` | `Record<string, Record<string, boolean>>` | Outer key: `${year}-W${week}_${dayIndex}`, inner key: `${sectionName}_${exerciseIndex}` |
| `aw_progress` | `ProgressEntry[]` | Ordered array of metric snapshots |
| `aw_sessions` | `TableSession[]` | Table day logs, newest first |
| `aw_weakness` | `WeaknessRatings` | Current 1–10 self-assessment per AW attribute |

Completion resets naturally each week because the outer key encodes the ISO week number.

### Chart.js registration
`Chart.js` components are registered at the top of `index.tsx`:
- `CategoryScale`, `LinearScale`, `LineElement`, `PointElement` — for Line charts
- `RadialLinearScale` — for Radar chart
- `Title`, `Tooltip`, `Legend`, `Filler`

### Style approach
The design uses a hybrid of Tailwind CSS classes (in `styles.css` for global resets) and React inline styles (in `index.tsx`) for component-level theming. This was chosen because:
1. The color palette uses CSS custom properties that benefit from centralized definition
2. Dynamic styles (conditional borders, progress bar widths) are cleaner as inline styles

### Theme
Dark glassmorphism. Background `#08090a`, card surfaces `rgba(255,255,255,0.025)`, borders `rgba(255,255,255,0.06)`. Three accent colors:
- Gold `#c8a84b` — strength / armwrestling focus
- Green `#52b788` — recovery / success / completed
- Blue `#5b8dee` — legs/shoulders day, progress tracking
- Red `#e05252` — weakness areas, losses

## Development Commands

```bash
npm run dev      # Start dev server (port 3000, Netlify CLI wraps at 8888)
npm run build    # Production build
npm run preview  # Preview production build
```

## Conventions

### Naming
- Components: PascalCase
- Utilities/hooks: camelCase
- Routes: kebab-case files

### TypeScript
- Strict mode enabled
- Import paths use `@/` alias for `src/*`
- All interfaces are defined at the top of the file that uses them

### Adding a new training day or exercise
Edit the `SCHEDULE` array in `src/routes/index.tsx`. The completion system tracks by section name + exercise index, so reordering exercises within a section will misalign existing saved completions for that week.
