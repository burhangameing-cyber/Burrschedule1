# AW Training Hub

A personal hybrid training dashboard for armwrestling performance and general strength/aesthetics. Built with TanStack Start and deployed on Netlify.

## What it does

A four-tab single-page app that tracks:

- **Schedule** — Full week training plan with collapsible day cards, exercise checkboxes, completion tracking, and weekly adherence percentage. All data persists to localStorage and resets each week.
- **Progress** — PR logging form for 7 metrics (bodyweight, bench, pullup max, weighted pullup, hammer curl, cheat curl, wrist curl) with line charts that appear automatically after 2+ entries.
- **Table** — Saturday armwrestling session log (rounds, wins, losses, notes) plus an AW strength radar chart and 1–10 self-assessment sliders for supination, side pressure, back pressure, finger containment, arm integrity, and endurance.
- **Profile** — Editable athlete profile card (name, age, height, weight, goal weight, arm measurements, style, notes) with inline auto-save.

## Tech stack

| Layer | Technology |
|---|---|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 + inline styles |
| Charts | Chart.js + react-chartjs-2 |
| Fonts | Syne (display) + JetBrains Mono (data) |
| Persistence | localStorage |
| Deployment | Netlify |

## Running locally

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

Build for production:

```bash
npm run build
```
