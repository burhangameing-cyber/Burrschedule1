import { createFileRoute } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  LineElement,
  PointElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js'
import { Line, Radar } from 'react-chartjs-2'

ChartJS.register(
  CategoryScale,
  LinearScale,
  LineElement,
  PointElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
  Filler,
)

export const Route = createFileRoute('/')({ component: Dashboard })

// ─── Types ────────────────────────────────────────────────────────────────────

interface Exercise {
  name: string
  sets: string
  reps: string
  rest: string
  note?: string
}
interface Section {
  name: string
  exercises: Exercise[]
}
interface DayData {
  day: string
  short: string
  label: string
  tag: string
  tagColor: string
  duration: string
  intensity: 'rest' | 'light' | 'heavy'
  sections: Section[]
}
interface Profile {
  name: string
  age: string
  height: string
  weight: string
  goalWeight: string
  armCirc: string
  forearmCirc: string
  style: string
  notes: string
}
interface ProgressEntry {
  date: string
  bodyweight: string
  pullupReps: string
  bench: string
  weightedPullup: string
  hammerCurl: string
  cheatCurl: string
  wristCurl: string
}
interface TableSession {
  date: string
  hardRounds: string
  wins: string
  losses: string
  mainFocus: string
  notes: string
}
interface WeaknessRatings {
  supination: number
  sidePressure: number
  backPressure: number
  fingerContainment: number
  armIntegrity: number
  endurance: number
}

// ─── Schedule data ────────────────────────────────────────────────────────────

const SCHEDULE: DayData[] = [
  {
    day: 'Monday',
    short: 'MON',
    label: 'Chest · Biceps · Toproll',
    tag: 'STRENGTH + AW',
    tagColor: '#c8a84b',
    duration: '1h 45m – 2h 15m',
    intensity: 'heavy',
    sections: [
      {
        name: 'Chest',
        exercises: [
          { name: 'Bench Press', sets: '4', reps: '6–10', rest: '3 min' },
          { name: 'Incline DB Press', sets: '3', reps: '8–12', rest: '2–3 min' },
          { name: 'Flyes', sets: '2', reps: '12–15', rest: '1–2 min' },
        ],
      },
      {
        name: 'Biceps',
        exercises: [
          { name: 'Barbell Curl', sets: '3', reps: '8–10', rest: '2–3 min' },
          { name: 'Hammer Curl', sets: '3', reps: '8–10', rest: '2–3 min' },
          { name: 'Incline Curl', sets: '2', reps: '10', rest: '1.5–2 min' },
          { name: 'Cheat Curl', sets: '2', reps: '5–8', rest: '3 min' },
        ],
      },
      {
        name: 'AW — Outside',
        exercises: [
          { name: 'Pronation Cable', sets: '3', reps: '8–12', rest: '2 min' },
          { name: 'Rising Holds', sets: '3', reps: '15–20s', rest: '2 min' },
          { name: 'Back Pressure Holds', sets: '3', reps: '15–20s', rest: '2–3 min' },
          { name: 'Posting Holds', sets: '2', reps: '20s', rest: '2 min' },
          { name: 'Finger Containment', sets: '2', reps: '12', rest: '1–2 min' },
          { name: 'Heavy Wrist Curl', sets: '3', reps: '8–10', rest: '2 min' },
        ],
      },
      {
        name: 'Shoulders',
        exercises: [
          { name: 'Overhead Press', sets: '3', reps: '8–10', rest: '2.5–3 min' },
          { name: 'Lateral Raise', sets: '3', reps: '12–15', rest: '1 min' },
          { name: 'Face Pull', sets: '2', reps: '15', rest: '1 min' },
        ],
      },
      {
        name: 'Traps + Skill',
        exercises: [
          { name: 'Shrugs', sets: '3', reps: '12–15', rest: '1–2 min' },
          { name: 'Dead Hang', sets: '2', reps: '40s', rest: '60s' },
          { name: 'L-sit practice', sets: '1', reps: '5 min', rest: '—' },
        ],
      },
    ],
  },
  {
    day: 'Tuesday',
    short: 'TUE',
    label: 'Recovery + Technique',
    tag: 'LIGHT',
    tagColor: '#52b788',
    duration: '40–60 min',
    intensity: 'light',
    sections: [
      {
        name: 'Blood Flow',
        exercises: [
          { name: 'External Rotations', sets: '3', reps: '20', rest: '30s' },
          { name: 'Light Wrist Curl', sets: '2', reps: '20', rest: '30s' },
          { name: 'Light Pronation', sets: '2', reps: '20', rest: '30s' },
          { name: 'Light Supination', sets: '2', reps: '20', rest: '30s' },
          { name: 'Dead Hangs', sets: '3', reps: '40s', rest: '45s' },
        ],
      },
      {
        name: 'AW Technique',
        exercises: [
          { name: 'DIY Hook Motion', sets: '3', reps: '10', rest: '60s' },
          { name: 'DIY Toproll Motion', sets: '3', reps: '10', rest: '60s' },
          {
            name: 'Table Technique',
            sets: '1',
            reps: '20–30 min',
            rest: '—',
            note: 'EASY',
          },
        ],
      },
    ],
  },
  {
    day: 'Wednesday',
    short: 'WED',
    label: 'Back · Triceps · Hook',
    tag: 'STRENGTH + AW',
    tagColor: '#c8a84b',
    duration: '1h 45m – 2h 20m',
    intensity: 'heavy',
    sections: [
      {
        name: 'Back',
        exercises: [
          { name: 'Weighted Pullups', sets: '4', reps: '6–8', rest: '3 min' },
          { name: 'Lat Pulldown', sets: '3', reps: '8–10', rest: '2 min' },
          { name: 'Seated Row', sets: '3', reps: '8–10', rest: '2 min' },
          { name: 'One Arm DB Row', sets: '3', reps: '8–10', rest: '2 min' },
          { name: 'Face Pull', sets: '2', reps: '15', rest: '1 min' },
        ],
      },
      {
        name: 'Triceps',
        exercises: [
          { name: 'Pushdowns', sets: '3', reps: '12–15', rest: '1–2 min' },
          { name: 'Overhead Extension', sets: '2', reps: '12–15', rest: '1–2 min' },
        ],
      },
      {
        name: 'AW — Inside',
        exercises: [
          { name: 'Supination Strap', sets: '3', reps: '12–20', rest: '2 min' },
          {
            name: 'Side Pressure Isometric',
            sets: '3',
            reps: '15–20s',
            rest: '2–3 min',
          },
          { name: 'Hook Static Hold', sets: '2', reps: '15–20s', rest: '2 min' },
          {
            name: 'Internal Rotation Pressure',
            sets: '2',
            reps: '12',
            rest: '2 min',
          },
          {
            name: 'Elbow Angle Hold ~90°',
            sets: '3',
            reps: '20s',
            rest: '2–3 min',
          },
          { name: 'Moderate Wrist Curl', sets: '2', reps: '12', rest: '1–2 min' },
          { name: 'Reverse Curl', sets: '2', reps: '10', rest: '2 min' },
          {
            name: 'Hammer Curl',
            sets: '2',
            reps: '8–10',
            rest: '2–3 min',
            note: 'OPTIONAL',
          },
        ],
      },
    ],
  },
  {
    day: 'Thursday',
    short: 'THU',
    label: 'Legs · Core · Shoulders',
    tag: 'STRENGTH',
    tagColor: '#5b8dee',
    duration: '1h 30m – 2h',
    intensity: 'heavy',
    sections: [
      {
        name: 'Legs',
        exercises: [
          { name: 'Squat', sets: '4', reps: '6–10', rest: '3–4 min' },
          { name: 'Romanian Deadlift', sets: '3', reps: '8–10', rest: '2–3 min' },
          { name: 'Leg Press / Lunge', sets: '3', reps: '10', rest: '2 min' },
          { name: 'Nordic Curl', sets: '3', reps: '5', rest: '2–3 min' },
          { name: 'Calves', sets: '3', reps: '20', rest: '1 min' },
        ],
      },
      {
        name: 'Core',
        exercises: [
          { name: 'Hanging Leg Raise', sets: '4', reps: '12', rest: '1 min' },
          { name: 'Weighted Plank', sets: '3', reps: '45s', rest: '1 min' },
          { name: 'Dragon Flag / Ab Wheel', sets: '3', reps: '8', rest: '90s' },
        ],
      },
      {
        name: 'Shoulders + Skill',
        exercises: [
          { name: 'Rear Delt Fly', sets: '3', reps: '15', rest: '1 min' },
          { name: 'Arnold Press', sets: '3', reps: '10', rest: '2 min' },
          { name: 'Y Raise', sets: '2', reps: '15', rest: '1 min' },
          { name: 'Handstand practice', sets: '1', reps: '5–10 min', rest: '—' },
          { name: 'Scap pullups', sets: '3', reps: '10', rest: '60s' },
          { name: 'L-sits', sets: '3', reps: '10–20s', rest: '45s' },
        ],
      },
    ],
  },
  {
    day: 'Friday',
    short: 'FRI',
    label: 'Full Rest',
    tag: 'REST',
    tagColor: '#4a4846',
    duration: 'No training',
    intensity: 'rest',
    sections: [],
  },
  {
    day: 'Saturday',
    short: 'SAT',
    label: 'Table Day',
    tag: 'TABLE',
    tagColor: '#c8a84b',
    duration: '1.5 – 3+ hrs',
    intensity: 'heavy',
    sections: [
      {
        name: 'Session',
        exercises: [
          { name: 'Warmup rounds', sets: '—', reps: 'Light pace', rest: '—' },
          { name: 'Hard rounds', sets: '6–8', reps: 'Max effort', rest: '2–5 min' },
          {
            name: 'Technique rounds',
            sets: '3–5',
            reps: 'Focused',
            rest: '2 min',
          },
          {
            name: 'Losing position drill',
            sets: '3',
            reps: 'Reset + learn',
            rest: '2 min',
          },
          {
            name: 'Straps work',
            sets: '3',
            reps: 'Supination + side focus',
            rest: '2 min',
          },
        ],
      },
    ],
  },
  {
    day: 'Sunday',
    short: 'SUN',
    label: 'Active Recovery',
    tag: 'RECOVERY',
    tagColor: '#52b788',
    duration: '30–45 min',
    intensity: 'light',
    sections: [
      {
        name: 'Recovery',
        exercises: [
          { name: 'Walk', sets: '1', reps: '30–45 min', rest: '—' },
          { name: 'Shoulder mobility', sets: '2', reps: '5 min', rest: '—' },
          { name: 'Forearm release', sets: '2', reps: '5 min', rest: '—' },
          { name: 'Sleep priority', sets: '—', reps: '8+ hrs', rest: '—' },
        ],
      },
    ],
  },
]

// ─── Helpers ──────────────────────────────────────────────────────────────────

function ls<T>(k: string, d: T): T {
  try {
    const v = localStorage.getItem(k)
    return v ? (JSON.parse(v) as T) : d
  } catch {
    return d
  }
}
function ss<T>(k: string, v: T) {
  try {
    localStorage.setItem(k, JSON.stringify(v))
  } catch {}
}

function weekKey(): string {
  const d = new Date()
  const j = new Date(d.getFullYear(), 0, 1)
  const w = Math.ceil(
    ((d.getTime() - j.getTime()) / 86400000 + j.getDay() + 1) / 7,
  )
  return `${d.getFullYear()}-W${w}`
}
function todayIdx(): number {
  const d = new Date().getDay()
  return d === 0 ? 6 : d - 1
}
function totalEx(day: DayData) {
  return day.sections.reduce((s, sec) => s + sec.exercises.length, 0)
}

// ─── Shared input style ────────────────────────────────────────────────────────

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '9px 12px',
  borderRadius: 8,
  background: 'rgba(255,255,255,0.04)',
  border: '1px solid rgba(255,255,255,0.09)',
  color: '#ede9e3',
  fontSize: 13,
  fontFamily: "'JetBrains Mono', monospace",
  outline: 'none',
  transition: 'border-color 0.15s',
}

const cardStyle: React.CSSProperties = {
  background: 'rgba(255,255,255,0.025)',
  border: '1px solid rgba(255,255,255,0.06)',
  borderRadius: 14,
  padding: '20px 22px',
}

const labelStyle: React.CSSProperties = {
  fontSize: 10,
  color: '#6b6966',
  textTransform: 'uppercase',
  letterSpacing: '0.1em',
  display: 'block',
  marginBottom: 6,
  fontWeight: 600,
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

function Dashboard() {
  type Tab = 'schedule' | 'progress' | 'table' | 'profile'
  const [tab, setTab] = useState<Tab>('schedule')
  const [mounted, setMounted] = useState(false)

  const [profile, setProfile] = useState<Profile>(() =>
    ls('aw_profile', {
      name: 'Athlete',
      age: '20',
      height: "5'11\"",
      weight: '75',
      goalWeight: '75',
      armCirc: '',
      forearmCirc: '',
      style: 'Toproll / Outside',
      notes: '',
    }),
  )
  const [completion, setCompletion] = useState<
    Record<string, Record<string, boolean>>
  >(() => ls('aw_completion', {}))
  const [expanded, setExpanded] = useState<Set<number>>(
    () => new Set([todayIdx()]),
  )
  const [progress, setProgress] = useState<ProgressEntry[]>(() =>
    ls('aw_progress', []),
  )
  const [sessions, setSessions] = useState<TableSession[]>(() =>
    ls('aw_sessions', []),
  )
  const [weakness, setWeakness] = useState<WeaknessRatings>(() =>
    ls('aw_weakness', {
      supination: 4,
      sidePressure: 4,
      backPressure: 6,
      fingerContainment: 5,
      armIntegrity: 3,
      endurance: 5,
    }),
  )
  const [newProg, setNewProg] = useState<ProgressEntry>({
    date: new Date().toISOString().split('T')[0],
    bodyweight: '',
    pullupReps: '',
    bench: '',
    weightedPullup: '',
    hammerCurl: '',
    cheatCurl: '',
    wristCurl: '',
  })
  const [newSess, setNewSess] = useState<TableSession>({
    date: new Date().toISOString().split('T')[0],
    hardRounds: '',
    wins: '',
    losses: '',
    mainFocus: '',
    notes: '',
  })

  const wk = weekKey()
  const todayI = todayIdx()

  useEffect(() => setMounted(true), [])
  useEffect(() => ss('aw_profile', profile), [profile])
  useEffect(() => ss('aw_completion', completion), [completion])
  useEffect(() => ss('aw_progress', progress), [progress])
  useEffect(() => ss('aw_sessions', sessions), [sessions])
  useEffect(() => ss('aw_weakness', weakness), [weakness])

  function toggleEx(dayIdx: number, exKey: string) {
    const dk = `${wk}_${dayIdx}`
    setCompletion((prev) => ({
      ...prev,
      [dk]: { ...prev[dk], [exKey]: !prev[dk]?.[exKey] },
    }))
  }

  function dayComp(dayIdx: number) {
    const dk = `${wk}_${dayIdx}`
    const checked = Object.values(completion[dk] || {}).filter(Boolean).length
    const total = totalEx(SCHEDULE[dayIdx])
    return { checked, total, pct: total > 0 ? (checked / total) * 100 : 0 }
  }

  function weeklyAdherence() {
    const active = [0, 1, 2, 3, 5, 6]
    let done = 0,
      possible = 0
    for (const i of active) {
      const c = dayComp(i)
      done += c.checked
      possible += c.total
    }
    return possible > 0 ? Math.round((done / possible) * 100) : 0
  }

  const adherence = weeklyAdherence()
  const today = SCHEDULE[todayI]
  const todayComp = dayComp(todayI)

  function buildLineData(
    field: keyof ProgressEntry,
    label: string,
    color: string,
  ) {
    const entries = [...progress].sort((a, b) => a.date.localeCompare(b.date))
    return {
      labels: entries.map((e) => e.date.slice(5)),
      datasets: [
        {
          label,
          data: entries.map((e) => {
            const v = parseFloat(e[field])
            return isNaN(v) ? null : v
          }),
          borderColor: color,
          backgroundColor: color + '20',
          fill: true,
          tension: 0.4,
          pointBackgroundColor: color,
          pointRadius: 4,
          spanGaps: true,
        },
      ],
    }
  }

  const chartOpts = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
      x: {
        grid: { color: 'rgba(255,255,255,0.04)' },
        ticks: { color: '#4a4846', font: { size: 10 } },
      },
      y: {
        grid: { color: 'rgba(255,255,255,0.04)' },
        ticks: { color: '#4a4846', font: { size: 10 } },
        beginAtZero: false,
      },
    },
  }

  const radarData = {
    labels: [
      'Supination',
      'Side Pressure',
      'Back Pressure',
      'Finger Contain.',
      'Arm Integrity',
      'Endurance',
    ],
    datasets: [
      {
        label: 'Current',
        data: [
          weakness.supination,
          weakness.sidePressure,
          weakness.backPressure,
          weakness.fingerContainment,
          weakness.armIntegrity,
          weakness.endurance,
        ],
        borderColor: '#c8a84b',
        backgroundColor: 'rgba(200,168,75,0.12)',
        pointBackgroundColor: '#c8a84b',
        borderWidth: 2,
      },
      {
        label: 'Target',
        data: [10, 10, 10, 10, 10, 10],
        borderColor: 'rgba(255,255,255,0.08)',
        backgroundColor: 'rgba(255,255,255,0.02)',
        pointBackgroundColor: 'rgba(255,255,255,0.15)',
        pointRadius: 2,
        borderWidth: 1,
      },
    ],
  }

  const radarOpts = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
      r: {
        min: 0,
        max: 10,
        grid: { color: 'rgba(255,255,255,0.07)' },
        angleLines: { color: 'rgba(255,255,255,0.07)' },
        ticks: { display: false },
        pointLabels: {
          color: '#6b6966',
          font: { size: 11 },
        },
      },
    },
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: 'schedule', label: 'Schedule' },
    { id: 'progress', label: 'Progress' },
    { id: 'table', label: 'Table' },
    { id: 'profile', label: 'Profile' },
  ]

  const weaknessFields: {
    key: keyof WeaknessRatings
    label: string
    color: string
  }[] = [
    { key: 'supination', label: 'Supination', color: '#e05252' },
    { key: 'sidePressure', label: 'Side Pressure', color: '#e05252' },
    { key: 'backPressure', label: 'Back Pressure', color: '#c8a84b' },
    { key: 'fingerContainment', label: 'Finger Containment', color: '#c8a84b' },
    { key: 'armIntegrity', label: 'Arm Integrity', color: '#e05252' },
    { key: 'endurance', label: 'Endurance', color: '#c8a84b' },
  ]

  const progFields: {
    key: keyof ProgressEntry
    label: string
    type: string
  }[] = [
    { key: 'date', label: 'Date', type: 'date' },
    { key: 'bodyweight', label: 'Bodyweight (kg)', type: 'number' },
    { key: 'bench', label: 'Bench PR (kg)', type: 'number' },
    { key: 'pullupReps', label: 'Pullup Max (reps)', type: 'number' },
    { key: 'weightedPullup', label: 'Weighted Pullup (+kg)', type: 'number' },
    { key: 'hammerCurl', label: 'Hammer Curl (kg)', type: 'number' },
    { key: 'cheatCurl', label: 'Cheat Curl (kg)', type: 'number' },
    { key: 'wristCurl', label: 'Wrist Curl (kg)', type: 'number' },
  ]

  const sessFields: {
    key: keyof TableSession
    label: string
    type: string
  }[] = [
    { key: 'date', label: 'Date', type: 'date' },
    { key: 'hardRounds', label: 'Hard Rounds', type: 'number' },
    { key: 'wins', label: 'Wins', type: 'number' },
    { key: 'losses', label: 'Losses', type: 'number' },
    { key: 'mainFocus', label: 'Main Focus', type: 'text' },
  ]

  const profileFields: {
    key: keyof Profile
    label: string
    type: string
  }[] = [
    { key: 'name', label: 'Name', type: 'text' },
    { key: 'age', label: 'Age', type: 'number' },
    { key: 'height', label: 'Height', type: 'text' },
    { key: 'weight', label: 'Weight (kg)', type: 'number' },
    { key: 'goalWeight', label: 'Goal Weight (kg)', type: 'number' },
    { key: 'armCirc', label: 'Arm Circ. (cm)', type: 'number' },
    { key: 'forearmCirc', label: 'Forearm Circ. (cm)', type: 'number' },
    { key: 'style', label: 'AW Style', type: 'text' },
  ]

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#08090a',
        color: '#ede9e3',
        fontFamily: "system-ui, -apple-system, 'Helvetica Neue', sans-serif",
      }}
    >
      {/* ─── Header ─── */}
      <header
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 100,
          background: 'rgba(8,9,10,0.94)',
          backdropFilter: 'blur(16px)',
          borderBottom: '1px solid rgba(255,255,255,0.06)',
          padding: '14px 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 16,
        }}
      >
        <div>
          <div
            style={{
              fontFamily: "'Syne', sans-serif",
              fontWeight: 800,
              fontSize: 17,
              letterSpacing: '-0.4px',
              color: '#ede9e3',
            }}
          >
            {profile.name || 'AW Training Hub'}
          </div>
          <div
            style={{
              fontSize: 10,
              color: '#3a3836',
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              marginTop: 2,
            }}
          >
            Training Hub
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              padding: '5px 12px',
              borderRadius: 7,
              background:
                adherence > 70
                  ? 'rgba(82,183,136,0.12)'
                  : 'rgba(200,168,75,0.12)',
              border: `1px solid ${adherence > 70 ? 'rgba(82,183,136,0.25)' : 'rgba(200,168,75,0.25)'}`,
              color: adherence > 70 ? '#52b788' : '#c8a84b',
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 12,
              fontWeight: 600,
            }}
          >
            {adherence}% this week
          </div>
        </div>
      </header>

      {/* ─── Tab nav ─── */}
      <nav
        style={{
          display: 'flex',
          gap: 2,
          padding: '10px 20px',
          borderBottom: '1px solid rgba(255,255,255,0.04)',
          overflowX: 'auto',
        }}
      >
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            style={{
              padding: '7px 18px',
              borderRadius: 8,
              border:
                tab === t.id
                  ? '1px solid rgba(200,168,75,0.3)'
                  : '1px solid transparent',
              cursor: 'pointer',
              fontSize: 12,
              fontWeight: 600,
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              transition: 'all 0.15s',
              whiteSpace: 'nowrap',
              background:
                tab === t.id ? 'rgba(200,168,75,0.12)' : 'transparent',
              color: tab === t.id ? '#c8a84b' : '#4a4846',
              fontFamily:
                "system-ui, -apple-system, 'Helvetica Neue', sans-serif",
            }}
          >
            {t.label}
          </button>
        ))}
      </nav>

      {/* ─── Main content ─── */}
      <main
        style={{ maxWidth: 1120, margin: '0 auto', padding: '24px 16px 60px' }}
      >
        {/* ══════════════════════════════════════════
            SCHEDULE TAB
        ══════════════════════════════════════════ */}
        {tab === 'schedule' && (
          <div>
            {/* Today hero */}
            <div
              style={{
                background: 'rgba(200,168,75,0.05)',
                border: '1px solid rgba(200,168,75,0.16)',
                borderRadius: 16,
                padding: '22px 26px',
                marginBottom: 24,
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  gap: 16,
                  flexWrap: 'wrap',
                }}
              >
                <div>
                  <div
                    style={{
                      fontSize: 10,
                      color: '#4a4846',
                      letterSpacing: '0.14em',
                      textTransform: 'uppercase',
                      marginBottom: 8,
                    }}
                  >
                    Today — {today.day}
                  </div>
                  <div
                    style={{
                      fontFamily: "'Syne', sans-serif",
                      fontWeight: 700,
                      fontSize: 24,
                      letterSpacing: '-0.5px',
                    }}
                  >
                    {today.label}
                  </div>
                  <div style={{ fontSize: 13, color: '#6b6966', marginTop: 5 }}>
                    {today.duration}
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div
                    style={{
                      fontFamily: "'JetBrains Mono', monospace",
                      fontSize: 36,
                      fontWeight: 600,
                      color: todayComp.pct > 0 ? '#c8a84b' : '#2a2a2a',
                      lineHeight: 1,
                    }}
                  >
                    {todayComp.checked}
                    <span style={{ fontSize: 18, color: '#3a3836' }}>
                      /{todayComp.total}
                    </span>
                  </div>
                  <div
                    style={{
                      fontSize: 10,
                      color: '#4a4846',
                      textTransform: 'uppercase',
                      letterSpacing: '0.08em',
                      marginTop: 4,
                    }}
                  >
                    exercises done
                  </div>
                </div>
              </div>
              {todayComp.total > 0 && (
                <div
                  style={{
                    marginTop: 18,
                    height: 3,
                    background: 'rgba(255,255,255,0.05)',
                    borderRadius: 2,
                    overflow: 'hidden',
                  }}
                >
                  <div
                    style={{
                      height: '100%',
                      width: `${todayComp.pct}%`,
                      background:
                        'linear-gradient(90deg, #c8a84b, #e8c875)',
                      borderRadius: 2,
                      transition: 'width 0.5s ease',
                    }}
                  />
                </div>
              )}
            </div>

            {/* Week grid */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
                gap: 12,
              }}
            >
              {SCHEDULE.map((day, idx) => {
                const comp = dayComp(idx)
                const isToday = idx === todayI
                const isExp = expanded.has(idx)

                return (
                  <div
                    key={day.day}
                    style={{
                      background: isToday
                        ? 'rgba(200,168,75,0.04)'
                        : 'rgba(255,255,255,0.022)',
                      border: `1px solid ${isToday ? 'rgba(200,168,75,0.18)' : 'rgba(255,255,255,0.06)'}`,
                      borderRadius: 14,
                      overflow: 'hidden',
                      transition: 'border-color 0.2s',
                    }}
                  >
                    {/* Card header */}
                    <div
                      onClick={() =>
                        setExpanded((prev) => {
                          const s = new Set(prev)
                          s.has(idx) ? s.delete(idx) : s.add(idx)
                          return s
                        })
                      }
                      style={{
                        padding: '15px 18px',
                        cursor: 'pointer',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        gap: 12,
                      }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 7,
                            flexWrap: 'wrap',
                          }}
                        >
                          <span
                            style={{
                              fontFamily: "'JetBrains Mono', monospace",
                              fontSize: 10,
                              fontWeight: 600,
                              color: '#3a3836',
                              letterSpacing: '0.12em',
                            }}
                          >
                            {day.short}
                          </span>
                          <span
                            style={{
                              fontSize: 9,
                              padding: '2px 7px',
                              borderRadius: 4,
                              background: `${day.tagColor}18`,
                              color: day.tagColor,
                              letterSpacing: '0.07em',
                              fontWeight: 700,
                            }}
                          >
                            {day.tag}
                          </span>
                          {isToday && (
                            <span
                              style={{
                                fontSize: 9,
                                padding: '2px 6px',
                                borderRadius: 4,
                                background: 'rgba(200,168,75,0.18)',
                                color: '#c8a84b',
                                letterSpacing: '0.07em',
                                fontWeight: 700,
                              }}
                            >
                              TODAY
                            </span>
                          )}
                        </div>
                        <div
                          style={{
                            fontFamily: "'Syne', sans-serif",
                            fontWeight: 600,
                            fontSize: 14,
                            marginTop: 5,
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >
                          {day.label}
                        </div>
                        <div
                          style={{
                            fontSize: 11,
                            color: '#4a4846',
                            marginTop: 2,
                          }}
                        >
                          {day.duration}
                        </div>
                      </div>
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          alignItems: 'flex-end',
                          gap: 6,
                          flexShrink: 0,
                        }}
                      >
                        {comp.total > 0 && (
                          <div
                            style={{
                              fontFamily: "'JetBrains Mono', monospace",
                              fontSize: 12,
                              color: comp.pct > 0 ? '#c8a84b' : '#3a3836',
                            }}
                          >
                            {comp.checked}/{comp.total}
                          </div>
                        )}
                        <div
                          style={{
                            color: '#3a3836',
                            fontSize: 10,
                            transform: isExp ? 'rotate(180deg)' : 'none',
                            transition: 'transform 0.2s',
                          }}
                        >
                          ▼
                        </div>
                      </div>
                    </div>

                    {/* Thin progress bar */}
                    {comp.total > 0 && (
                      <div
                        style={{
                          height: 2,
                          background: 'rgba(255,255,255,0.04)',
                        }}
                      >
                        <div
                          style={{
                            height: '100%',
                            width: `${comp.pct}%`,
                            background: '#c8a84b',
                            transition: 'width 0.4s ease',
                          }}
                        />
                      </div>
                    )}

                    {/* Expanded exercises */}
                    {isExp && day.sections.length > 0 && (
                      <div
                        style={{
                          padding: '14px 18px 18px',
                          borderTop: '1px solid rgba(255,255,255,0.05)',
                        }}
                      >
                        {day.sections.map((sec) => (
                          <div key={sec.name} style={{ marginBottom: 18 }}>
                            <div
                              style={{
                                fontSize: 9,
                                color: '#6b6966',
                                textTransform: 'uppercase',
                                letterSpacing: '0.14em',
                                fontWeight: 700,
                                marginBottom: 8,
                              }}
                            >
                              {sec.name}
                            </div>
                            {sec.exercises.map((ex, ei) => {
                              const exKey = `${sec.name}_${ei}`
                              const dk = `${wk}_${idx}`
                              const done = !!completion[dk]?.[exKey]
                              return (
                                <div
                                  key={exKey}
                                  onClick={() => toggleEx(idx, exKey)}
                                  style={{
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center',
                                    padding: '8px 10px',
                                    marginBottom: 3,
                                    borderRadius: 8,
                                    cursor: 'pointer',
                                    background: done
                                      ? 'rgba(82,183,136,0.07)'
                                      : 'rgba(255,255,255,0.02)',
                                    border: `1px solid ${done ? 'rgba(82,183,136,0.15)' : 'transparent'}`,
                                    transition: 'all 0.15s',
                                    gap: 8,
                                  }}
                                >
                                  <div
                                    style={{
                                      display: 'flex',
                                      alignItems: 'center',
                                      gap: 9,
                                      minWidth: 0,
                                    }}
                                  >
                                    <div
                                      style={{
                                        width: 14,
                                        height: 14,
                                        borderRadius: 3,
                                        flexShrink: 0,
                                        border: `1.5px solid ${done ? '#52b788' : 'rgba(255,255,255,0.14)'}`,
                                        background: done
                                          ? '#52b788'
                                          : 'transparent',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        transition: 'all 0.15s',
                                      }}
                                    >
                                      {done && (
                                        <span
                                          style={{
                                            fontSize: 8,
                                            color: '#0a0a0a',
                                            fontWeight: 900,
                                            lineHeight: 1,
                                          }}
                                        >
                                          ✓
                                        </span>
                                      )}
                                    </div>
                                    <div style={{ minWidth: 0 }}>
                                      <span
                                        style={{
                                          fontSize: 13,
                                          color: done ? '#3a3836' : '#ede9e3',
                                          textDecoration: done
                                            ? 'line-through'
                                            : 'none',
                                          transition: 'all 0.15s',
                                        }}
                                      >
                                        {ex.name}
                                      </span>
                                      {ex.note && (
                                        <span
                                          style={{
                                            fontSize: 9,
                                            marginLeft: 6,
                                            color: '#c8a84b',
                                            fontWeight: 700,
                                            letterSpacing: '0.06em',
                                          }}
                                        >
                                          {ex.note}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                  <div
                                    style={{
                                      display: 'flex',
                                      gap: 8,
                                      flexShrink: 0,
                                      alignItems: 'center',
                                    }}
                                  >
                                    <span
                                      style={{
                                        fontFamily:
                                          "'JetBrains Mono', monospace",
                                        fontSize: 11,
                                        color: '#6b6966',
                                        whiteSpace: 'nowrap',
                                      }}
                                    >
                                      {ex.sets}×{ex.reps}
                                    </span>
                                    <span
                                      style={{
                                        fontSize: 10,
                                        color: '#3a3836',
                                        whiteSpace: 'nowrap',
                                      }}
                                    >
                                      {ex.rest}
                                    </span>
                                  </div>
                                </div>
                              )
                            })}
                          </div>
                        ))}
                      </div>
                    )}

                    {isExp && day.intensity === 'rest' && (
                      <div
                        style={{
                          padding: '28px 18px',
                          borderTop: '1px solid rgba(255,255,255,0.05)',
                          textAlign: 'center',
                        }}
                      >
                        <div
                          style={{
                            fontFamily: "'JetBrains Mono', monospace",
                            fontSize: 28,
                            color: '#2a2a2a',
                            marginBottom: 10,
                          }}
                        >
                          — —
                        </div>
                        <div style={{ fontSize: 13, color: '#4a4846' }}>
                          No lifting. No armwrestling.
                        </div>
                        <div
                          style={{
                            fontSize: 11,
                            color: '#3a3836',
                            marginTop: 5,
                          }}
                        >
                          Full rest before table day.
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>

            {/* Deload note */}
            <div
              style={{
                marginTop: 20,
                padding: '13px 18px',
                borderRadius: 10,
                background: 'rgba(91,141,238,0.05)',
                border: '1px solid rgba(91,141,238,0.12)',
                fontSize: 12,
                color: '#6b6966',
                lineHeight: 1.7,
              }}
            >
              <span style={{ color: '#5b8dee', fontWeight: 600 }}>
                Deload every 5th week:
              </span>{' '}
              Reduce weight 20–30%, volume 30–40%. Still train every session.
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════
            PROGRESS TAB
        ══════════════════════════════════════════ */}
        {tab === 'progress' && (
          <div>
            {/* Latest stats row */}
            {progress.length > 0 &&
              (() => {
                const last = [...progress].sort((a, b) =>
                  b.date.localeCompare(a.date),
                )[0]
                const stats = [
                  {
                    label: 'Bodyweight',
                    val: last.bodyweight,
                    unit: 'kg',
                    color: '#c8a84b',
                  },
                  {
                    label: 'Bench',
                    val: last.bench,
                    unit: 'kg',
                    color: '#c8a84b',
                  },
                  {
                    label: 'Pullup Max',
                    val: last.pullupReps,
                    unit: 'reps',
                    color: '#52b788',
                  },
                  {
                    label: '+Pullup',
                    val: last.weightedPullup,
                    unit: 'kg',
                    color: '#52b788',
                  },
                  {
                    label: 'Hammer',
                    val: last.hammerCurl,
                    unit: 'kg',
                    color: '#5b8dee',
                  },
                  {
                    label: 'Cheat Curl',
                    val: last.cheatCurl,
                    unit: 'kg',
                    color: '#5b8dee',
                  },
                  {
                    label: 'Wrist Curl',
                    val: last.wristCurl,
                    unit: 'kg',
                    color: '#e87d5a',
                  },
                ]
                return (
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns:
                        'repeat(auto-fill, minmax(130px, 1fr))',
                      gap: 10,
                      marginBottom: 26,
                    }}
                  >
                    {stats
                      .filter((s) => s.val)
                      .map((s) => (
                        <div
                          key={s.label}
                          style={{
                            ...cardStyle,
                            padding: '14px 16px',
                          }}
                        >
                          <div
                            style={{
                              fontSize: 9,
                              color: '#4a4846',
                              textTransform: 'uppercase',
                              letterSpacing: '0.1em',
                              marginBottom: 7,
                              fontWeight: 600,
                            }}
                          >
                            {s.label}
                          </div>
                          <div
                            style={{
                              fontFamily: "'JetBrains Mono', monospace",
                              fontSize: 24,
                              fontWeight: 600,
                              color: s.color,
                              lineHeight: 1,
                            }}
                          >
                            {s.val}
                          </div>
                          <div
                            style={{
                              fontSize: 10,
                              color: '#3a3836',
                              marginTop: 4,
                            }}
                          >
                            {s.unit}
                          </div>
                        </div>
                      ))}
                  </div>
                )
              })()}

            {/* Log form */}
            <div style={{ ...cardStyle, marginBottom: 26 }}>
              <div
                style={{
                  fontFamily: "'Syne', sans-serif",
                  fontWeight: 700,
                  fontSize: 16,
                  marginBottom: 18,
                }}
              >
                Log Entry
              </div>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(165px, 1fr))',
                  gap: 14,
                }}
              >
                {progFields.map((f) => (
                  <div key={f.key}>
                    <label style={labelStyle}>{f.label}</label>
                    <input
                      type={f.type}
                      value={newProg[f.key]}
                      onChange={(e) =>
                        setNewProg((prev) => ({
                          ...prev,
                          [f.key]: e.target.value,
                        }))
                      }
                      style={inputStyle}
                    />
                  </div>
                ))}
              </div>
              <div
                style={{
                  display: 'flex',
                  gap: 10,
                  marginTop: 18,
                  alignItems: 'center',
                }}
              >
                <button
                  onClick={() => {
                    if (!newProg.date) return
                    setProgress((prev) => [...prev, newProg])
                    setNewProg({
                      date: new Date().toISOString().split('T')[0],
                      bodyweight: '',
                      pullupReps: '',
                      bench: '',
                      weightedPullup: '',
                      hammerCurl: '',
                      cheatCurl: '',
                      wristCurl: '',
                    })
                  }}
                  style={{
                    padding: '10px 22px',
                    borderRadius: 8,
                    border: 'none',
                    cursor: 'pointer',
                    background: '#c8a84b',
                    color: '#0a0a0a',
                    fontWeight: 700,
                    fontSize: 12,
                    letterSpacing: '0.07em',
                    textTransform: 'uppercase',
                  }}
                >
                  Save Entry
                </button>
                {progress.length > 0 && (
                  <span style={{ fontSize: 11, color: '#4a4846' }}>
                    {progress.length} entr{progress.length === 1 ? 'y' : 'ies'} logged
                  </span>
                )}
              </div>
            </div>

            {/* Charts */}
            {mounted && progress.length >= 2 ? (
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                  gap: 16,
                }}
              >
                {(
                  [
                    {
                      field: 'bodyweight' as keyof ProgressEntry,
                      label: 'Bodyweight',
                      color: '#c8a84b',
                    },
                    {
                      field: 'bench' as keyof ProgressEntry,
                      label: 'Bench PR',
                      color: '#c8a84b',
                    },
                    {
                      field: 'pullupReps' as keyof ProgressEntry,
                      label: 'Pullup Max',
                      color: '#52b788',
                    },
                    {
                      field: 'weightedPullup' as keyof ProgressEntry,
                      label: 'Weighted Pullup',
                      color: '#52b788',
                    },
                    {
                      field: 'hammerCurl' as keyof ProgressEntry,
                      label: 'Hammer Curl',
                      color: '#5b8dee',
                    },
                    {
                      field: 'wristCurl' as keyof ProgressEntry,
                      label: 'Wrist Curl',
                      color: '#e87d5a',
                    },
                  ] as const
                ).map((c) => (
                  <div
                    key={c.field}
                    style={{
                      ...cardStyle,
                      padding: '18px 20px',
                    }}
                  >
                    <div
                      style={{
                        fontSize: 11,
                        color: '#6b6966',
                        textTransform: 'uppercase',
                        letterSpacing: '0.1em',
                        marginBottom: 14,
                        fontWeight: 600,
                      }}
                    >
                      {c.label}
                    </div>
                    <Line
                      data={buildLineData(c.field, c.label, c.color)}
                      options={chartOpts}
                    />
                  </div>
                ))}
              </div>
            ) : (
              progress.length < 2 && (
                <div
                  style={{
                    textAlign: 'center',
                    padding: '50px 20px',
                    background: 'rgba(255,255,255,0.015)',
                    border: '1px solid rgba(255,255,255,0.04)',
                    borderRadius: 14,
                    color: '#3a3836',
                  }}
                >
                  <div
                    style={{
                      fontFamily: "'JetBrains Mono', monospace",
                      fontSize: 28,
                      marginBottom: 12,
                    }}
                  >
                    —
                  </div>
                  <div style={{ fontSize: 13, color: '#4a4846', marginBottom: 6 }}>
                    Log 2+ entries to see progress charts
                  </div>
                  <div style={{ fontSize: 11 }}>
                    Charts appear automatically as you track
                  </div>
                </div>
              )
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════
            TABLE TAB
        ══════════════════════════════════════════ */}
        {tab === 'table' && (
          <div>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                gap: 16,
                marginBottom: 24,
              }}
            >
              {/* Radar */}
              {mounted && (
                <div style={cardStyle}>
                  <div
                    style={{
                      fontFamily: "'Syne', sans-serif",
                      fontWeight: 700,
                      fontSize: 15,
                      marginBottom: 4,
                    }}
                  >
                    AW Strength Profile
                  </div>
                  <div
                    style={{
                      fontSize: 11,
                      color: '#4a4846',
                      marginBottom: 16,
                    }}
                  >
                    Self-assessment 1–10
                  </div>
                  <Radar data={radarData} options={radarOpts} />
                </div>
              )}

              {/* Weakness sliders */}
              <div style={cardStyle}>
                <div
                  style={{
                    fontFamily: "'Syne', sans-serif",
                    fontWeight: 700,
                    fontSize: 15,
                    marginBottom: 18,
                  }}
                >
                  Rate Your Areas
                </div>
                {weaknessFields.map((w) => (
                  <div key={w.key} style={{ marginBottom: 18 }}>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        marginBottom: 7,
                      }}
                    >
                      <span style={{ fontSize: 12, color: '#8c8986' }}>
                        {w.label}
                      </span>
                      <span
                        style={{
                          fontFamily: "'JetBrains Mono', monospace",
                          fontSize: 12,
                          color: w.color,
                          fontWeight: 600,
                        }}
                      >
                        {weakness[w.key]}/10
                      </span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={10}
                      value={weakness[w.key]}
                      onChange={(e) =>
                        setWeakness((prev) => ({
                          ...prev,
                          [w.key]: parseInt(e.target.value),
                        }))
                      }
                      style={{
                        width: '100%',
                        cursor: 'pointer',
                        accentColor: w.color,
                      }}
                    />
                    <div
                      style={{
                        height: 2,
                        background: 'rgba(255,255,255,0.05)',
                        borderRadius: 2,
                        marginTop: 5,
                        overflow: 'hidden',
                      }}
                    >
                      <div
                        style={{
                          height: '100%',
                          width: `${weakness[w.key] * 10}%`,
                          background: w.color + '88',
                          borderRadius: 2,
                          transition: 'width 0.2s',
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Session log form */}
            <div style={{ ...cardStyle, marginBottom: 20 }}>
              <div
                style={{
                  fontFamily: "'Syne', sans-serif",
                  fontWeight: 700,
                  fontSize: 16,
                  marginBottom: 18,
                }}
              >
                Log Table Session
              </div>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
                  gap: 14,
                }}
              >
                {sessFields.map((f) => (
                  <div key={f.key}>
                    <label style={labelStyle}>{f.label}</label>
                    <input
                      type={f.type}
                      value={newSess[f.key]}
                      onChange={(e) =>
                        setNewSess((prev) => ({
                          ...prev,
                          [f.key]: e.target.value,
                        }))
                      }
                      style={inputStyle}
                    />
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 14 }}>
                <label style={labelStyle}>Session Notes</label>
                <textarea
                  value={newSess.notes}
                  onChange={(e) =>
                    setNewSess((prev) => ({ ...prev, notes: e.target.value }))
                  }
                  rows={3}
                  placeholder="What worked? Positions that felt strong. Areas to drill next session..."
                  style={{
                    ...inputStyle,
                    resize: 'vertical',
                    lineHeight: 1.6,
                    fontFamily:
                      "system-ui, -apple-system, 'Helvetica Neue', sans-serif",
                  }}
                />
              </div>
              <button
                onClick={() => {
                  if (!newSess.date) return
                  setSessions((prev) => [newSess, ...prev])
                  setNewSess({
                    date: new Date().toISOString().split('T')[0],
                    hardRounds: '',
                    wins: '',
                    losses: '',
                    mainFocus: '',
                    notes: '',
                  })
                }}
                style={{
                  marginTop: 16,
                  padding: '10px 22px',
                  borderRadius: 8,
                  border: 'none',
                  cursor: 'pointer',
                  background: '#c8a84b',
                  color: '#0a0a0a',
                  fontWeight: 700,
                  fontSize: 12,
                  letterSpacing: '0.07em',
                  textTransform: 'uppercase',
                }}
              >
                Log Session
              </button>
            </div>

            {/* Past sessions */}
            {sessions.length > 0 ? (
              <div>
                <div
                  style={{
                    fontSize: 10,
                    color: '#4a4846',
                    textTransform: 'uppercase',
                    letterSpacing: '0.12em',
                    marginBottom: 12,
                    fontWeight: 600,
                  }}
                >
                  Session History
                </div>
                {sessions.map((s, i) => (
                  <div
                    key={i}
                    style={{
                      background: 'rgba(255,255,255,0.018)',
                      border: '1px solid rgba(255,255,255,0.05)',
                      borderRadius: 12,
                      padding: '14px 18px',
                      marginBottom: 10,
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: 8,
                        flexWrap: 'wrap',
                        gap: 8,
                      }}
                    >
                      <div
                        style={{
                          fontFamily: "'JetBrains Mono', monospace",
                          fontSize: 13,
                          color: '#c8a84b',
                          fontWeight: 600,
                        }}
                      >
                        {s.date}
                      </div>
                      <div
                        style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}
                      >
                        {s.hardRounds && (
                          <span style={{ fontSize: 12, color: '#6b6966' }}>
                            {s.hardRounds} rounds
                          </span>
                        )}
                        {s.wins && (
                          <span style={{ fontSize: 12, color: '#52b788' }}>
                            W: {s.wins}
                          </span>
                        )}
                        {s.losses && (
                          <span style={{ fontSize: 12, color: '#e05252' }}>
                            L: {s.losses}
                          </span>
                        )}
                      </div>
                    </div>
                    {s.mainFocus && (
                      <div
                        style={{
                          fontSize: 12,
                          color: '#8c8986',
                          marginBottom: 5,
                        }}
                      >
                        Focus: {s.mainFocus}
                      </div>
                    )}
                    {s.notes && (
                      <div
                        style={{
                          fontSize: 12,
                          color: '#6b6966',
                          lineHeight: 1.6,
                        }}
                      >
                        {s.notes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div
                style={{
                  textAlign: 'center',
                  padding: '40px 20px',
                  background: 'rgba(255,255,255,0.015)',
                  border: '1px solid rgba(255,255,255,0.04)',
                  borderRadius: 14,
                  color: '#3a3836',
                }}
              >
                <div style={{ fontSize: 13, color: '#4a4846', marginBottom: 6 }}>
                  No sessions logged yet
                </div>
                <div style={{ fontSize: 11 }}>
                  Log your Saturday table sessions above
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════
            PROFILE TAB
        ══════════════════════════════════════════ */}
        {tab === 'profile' && (
          <div>
            <div
              style={{
                fontFamily: "'Syne', sans-serif",
                fontWeight: 800,
                fontSize: 22,
                letterSpacing: '-0.5px',
                marginBottom: 22,
              }}
            >
              Athlete Profile
            </div>
            <div style={{ ...cardStyle, marginBottom: 20 }}>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
                  gap: 16,
                }}
              >
                {profileFields.map((f) => (
                  <div key={f.key}>
                    <label style={labelStyle}>{f.label}</label>
                    <input
                      type={f.type}
                      value={profile[f.key]}
                      onChange={(e) =>
                        setProfile((prev) => ({
                          ...prev,
                          [f.key]: e.target.value,
                        }))
                      }
                      style={inputStyle}
                    />
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 18 }}>
                <label style={labelStyle}>Notes</label>
                <textarea
                  value={profile.notes}
                  onChange={(e) =>
                    setProfile((prev) => ({ ...prev, notes: e.target.value }))
                  }
                  rows={4}
                  placeholder="Competition goals, injury history, training notes..."
                  style={{
                    ...inputStyle,
                    resize: 'vertical',
                    lineHeight: 1.6,
                    fontFamily:
                      "system-ui, -apple-system, 'Helvetica Neue', sans-serif",
                  }}
                />
              </div>
              <div
                style={{
                  marginTop: 14,
                  padding: '10px 14px',
                  borderRadius: 8,
                  background: 'rgba(82,183,136,0.07)',
                  border: '1px solid rgba(82,183,136,0.14)',
                  fontSize: 11,
                  color: '#52b788',
                }}
              >
                All changes save automatically to local storage
              </div>
            </div>

            {/* Strengths / Focus */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
                gap: 16,
                marginBottom: 20,
              }}
            >
              <div
                style={{
                  background: 'rgba(82,183,136,0.04)',
                  border: '1px solid rgba(82,183,136,0.12)',
                  borderRadius: 14,
                  padding: '20px 22px',
                }}
              >
                <div
                  style={{
                    fontFamily: "'Syne', sans-serif",
                    fontWeight: 700,
                    fontSize: 14,
                    color: '#52b788',
                    marginBottom: 14,
                  }}
                >
                  Strengths
                </div>
                {[
                  'Hand / wrist strength',
                  'Pronation',
                  'Recovery ability',
                  'Pullup strength (17 reps)',
                ].map((s) => (
                  <div
                    key={s}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 9,
                      marginBottom: 9,
                      fontSize: 13,
                      color: '#6b6966',
                    }}
                  >
                    <div
                      style={{
                        width: 5,
                        height: 5,
                        borderRadius: '50%',
                        background: '#52b788',
                        flexShrink: 0,
                      }}
                    />
                    {s}
                  </div>
                ))}
              </div>
              <div
                style={{
                  background: 'rgba(224,82,82,0.04)',
                  border: '1px solid rgba(224,82,82,0.12)',
                  borderRadius: 14,
                  padding: '20px 22px',
                }}
              >
                <div
                  style={{
                    fontFamily: "'Syne', sans-serif",
                    fontWeight: 700,
                    fontSize: 14,
                    color: '#e05252',
                    marginBottom: 14,
                  }}
                >
                  Focus Areas
                </div>
                {[
                  'Side pressure',
                  'Supination',
                  'Arm integrity (opens under load)',
                  'Late-round endurance',
                ].map((s) => (
                  <div
                    key={s}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 9,
                      marginBottom: 9,
                      fontSize: 13,
                      color: '#6b6966',
                    }}
                  >
                    <div
                      style={{
                        width: 5,
                        height: 5,
                        borderRadius: '50%',
                        background: '#e05252',
                        flexShrink: 0,
                      }}
                    />
                    {s}
                  </div>
                ))}
              </div>
              <div
                style={{
                  background: 'rgba(91,141,238,0.04)',
                  border: '1px solid rgba(91,141,238,0.12)',
                  borderRadius: 14,
                  padding: '20px 22px',
                }}
              >
                <div
                  style={{
                    fontFamily: "'Syne', sans-serif",
                    fontWeight: 700,
                    fontSize: 14,
                    color: '#5b8dee',
                    marginBottom: 14,
                  }}
                >
                  Equipment
                </div>
                {[
                  'Full gym access',
                  'Homemade wrist wrench',
                  'Pronation straps',
                  'Multispinner',
                  'Preacher curl for table practice',
                ].map((s) => (
                  <div
                    key={s}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 9,
                      marginBottom: 9,
                      fontSize: 13,
                      color: '#6b6966',
                    }}
                  >
                    <div
                      style={{
                        width: 5,
                        height: 5,
                        borderRadius: '50%',
                        background: '#5b8dee',
                        flexShrink: 0,
                      }}
                    />
                    {s}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
